# napari-CosMx

View CosMx images and data in napari

----------------------------------

This [napari] plugin was generated with [Cookiecutter] using [@napari]'s [cookiecutter-napari-plugin] template.

<!--
Don't miss the full getting started guide to set up your new package:
https://github.com/napari/cookiecutter-napari-plugin#getting-started

and review the napari docs for plugin developers:
https://napari.org/plugins/stable/index.html
-->

## Installation

First clone this repository to your local machine with the command:
```
git clone https://github.com/Nanostring-Biostats/napari-CosMx
```

The napari viewer is a Python-based application and requires you have Python on your system. A popular way to install Python is via the [Anaconda](https://www.anaconda.com/products/individual) platform. After you download Anaconda Individual Edition, run the installer and accept the defaults.

After installation is finished, there will be an Anaconda Prompt item in your Start menu. Click that and then type the following commands to create a new virtual environment for your napari installation.

```
conda create -y -n napari-env -c conda-forge python=3.9
conda activate napari-env
```


If successful your command prompt will now have a `(napari-env)` label on it.

You can now install napari, Jupyter notebook, and this napari-CosMx plugin.

```
pip install notebook
pip install "napari[all]"
```

To install `napari-CosMx` navigate to the root directory of this repository where you cloned it on your local machine, then:
```
pip install .
```

Finally, type `jupyter notebook` and navigate to the `vignettes` directory and open `gemini.ipynb`. If you are able to run the cells in that notebook your installation was successful.

## Issues

If you encounter any problems, please [file an issue] along with a detailed description.

[napari]: https://github.com/napari/napari
[Cookiecutter]: https://github.com/audreyr/cookiecutter
[@napari]: https://github.com/napari
[cookiecutter-napari-plugin]: https://github.com/napari/cookiecutter-napari-plugin

[file an issue]: https://github.com/Nanostring-Biostats/napari-CosMx/issues

[napari]: https://github.com/napari/napari
[tox]: https://tox.readthedocs.io/en/latest/
[pip]: https://pypi.org/project/pip/
[PyPI]: https://pypi.org/
