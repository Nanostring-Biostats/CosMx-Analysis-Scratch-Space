from __future__ import annotations
import numpy as np
import napari
from magicgui import magicgui
from napari.utils.transforms import Affine

# --- Alignment Tool Widget ---
@magicgui(
    call_button="Apply Alignment",
    flip_horizontal={"widget_type": "CheckBox", "text": "Flip Horiz (↔)", "value": False},
    flip_vertical={"widget_type": "CheckBox", "text": "Flip Verti (↕)", "value": False},
    rotation={"value": 0.0, "label": "Rotation (°)", "min": -180, "max": 180, "step": 1},
    scale_x={"value": 1.0, "label": "Scale Verti", "min": 0.0001, "max": 1000.0, "step": 0.0001},
    scale_y={"value": 1.0, "label": "Scale Horiz", "min": 0.0001, "max": 1000.0, "step": 0.0001},
    translate_x={"value": 0.0, "label": "Shift Verti", "min": -1000.0, "max": 1000.0, "step": 1},
    translate_y={"value": 0.0, "label": "Shift Horiz", "min": -1000.0, "max": 1000.0, "step": 1},
)
def apply_alignment(
    layer: napari.layers.Image,
    rotation: float,
    scale_x: float,
    scale_y: float,
    translate_x: float,
    translate_y: float,
    flip_horizontal: bool,
    flip_vertical: bool,
):
    """Apply coarse alignment transforms to the selected Image layer.

    Notes
    -----
    * Negative scale values flip the image.
    * Translation units are in data coordinates.
    * For 3D data, this adjusts the first two axes.
    """
    if layer is None:
        return

    # Adjust scale for flips
    final_scale_x = -abs(scale_x) if flip_vertical else abs(scale_x)
    final_scale_y = -abs(scale_y) if flip_horizontal else abs(scale_y)

    # Apply rotation/scale/translation
    layer.rotate = rotation
    layer.scale = (final_scale_x, final_scale_y)
    layer.translate = (translate_x, translate_y)

    # Optional: keep image roughly centered after flips (tweak for your data orientation)
    shape = layer.data.shape
    shift_x = shape[1] * final_scale_x if flip_vertical else 0
    shift_y = shape[0] * final_scale_y if flip_horizontal else 0
    layer.translate = (translate_x + shift_x, translate_y + shift_y)


# --- Fine Nudge Widget ---
@magicgui(
    layout="horizontal",
    call_button="Nudge",
    layer={"label": "Target Layer"},
    direction={"choices": ["← Y-", "→ Y+", "↑ X+", "↓ X-", "↺ Rotate-", "↻ Rotate+"]},
    step={"value": 1.0, "label": "Step", "min": 0.0001, "max": 100.0, "step": 0.001},
)
def fine_nudge(layer: napari.layers.Image, direction: str, step: float):
    """Small, precise translation or rotation of the current layer."""
    if layer is None:
        print("No layer selected for fine nudge.")
        return

    affine = layer.affine.affine_matrix.copy()

    if direction == "← Y-":
        affine[1, 2] -= step  # left
    elif direction == "→ Y+":
        affine[1, 2] += step  # right
    elif direction == "↑ X+":
        affine[0, 2] -= step  # up
    elif direction == "↓ X-":
        affine[0, 2] += step  # down
    elif direction in ["↺ Rotate-", "↻ Rotate+"]:
        theta = np.deg2rad(step) if direction == "↺ Rotate-" else -np.deg2rad(step)
        rotation = np.array([
            [np.cos(theta), -np.sin(theta), 0],
            [np.sin(theta),  np.cos(theta), 0],
            [0, 0, 1],
        ])
        affine = rotation @ affine

    layer.affine = Affine(affine_matrix=affine)

def add_widgets_to_viewer(viewer):
    # Add widgets to the napari viewer
    viewer.window.add_dock_widget(apply_alignment, name="Alignment Tool", area="right")
    viewer.window.add_dock_widget(fine_nudge, name="Fine Nudge", area="right")
