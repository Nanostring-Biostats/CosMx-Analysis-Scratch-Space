from __future__ import annotations

from typing import List

from ..datamodels import MarkerProgram
from .schema import _meta, _mp


def _immune_core() -> List[MarkerProgram]:
    cd4 = _mp("CD4 T cell", ["IL7R", "LTB", "MAL", "HLA-DRA", "TRAC"], ["NKG7", "PRF1"], metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))
    cd8 = _mp("CD8 T cell", ["NKG7", "CCL5", "PRF1", "GZMB", "TRAC"], ["IL7R"], metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))
    treg = _mp("Treg", ["IL2RA", "FOXP3", "TIGIT", "CTLA4", "LTB"], ["NKG7", "PRF1"], metadata=_meta("immune", "pan-tissue", "immune_core", role="optional", lineage_module="immune"))
    tcell = _mp("T cell", ["CD3D", "CD3E", "TRBC1", "TRAC", "LTB"], ["MS4A1", "LYZ"], [cd4, cd8, treg], "Pan-T lineage markers.", metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))

    plasma = _mp("Plasma cell", ["MZB1", "JCHAIN", "SDC1", "XBP1", "IGKC"], ["CD3D", "LYZ"], metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))
    bcell = _mp("B cell", ["MS4A1", "CD79A", "CD74", "HLA-DRA", "CD79B"], ["CD3D", "LYZ"], [plasma], metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))

    nk = _mp("NK cell", ["NKG7", "KLRD1", "GNLY", "PRF1", "FCGR3A"], ["CD3D", "MS4A1"], metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))
    macro = _mp("Macrophage", ["LYZ", "C1QA", "C1QB", "APOE", "FCER1G"], ["CD3D", "EPCAM"], metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))
    mono = _mp("Monocyte", ["LYZ", "S100A8", "S100A9", "CTSS", "FCN1"], ["CD3D", "EPCAM"], metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))
    dc = _mp("Dendritic cell", ["FCER1A", "CST3", "HLA-DRA", "CD74", "CLEC10A"], ["NKG7", "EPCAM"], metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))
    myeloid = _mp("Myeloid", ["LYZ", "TYMP", "FCER1G", "CTSS", "SAT1"], ["CD3D", "EPCAM"], [macro, mono, dc], metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))

    mast = _mp("Mast cell", ["TPSAB1", "TPSB2", "KIT", "CPA3", "HDC"], ["CD3D", "MS4A1"], metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))
    neut = _mp("Neutrophil", ["S100A8", "S100A9", "FCGR3B", "CXCR2", "CSF3R"], ["CD3D", "MS4A1"], metadata=_meta("immune", "pan-tissue", "immune_core", role="major", lineage_module="immune"))
    return [tcell, bcell, nk, myeloid, mast, neut]



def _parenchymal_fallback_core() -> List[MarkerProgram]:
    basal_ep = _mp(
        "Basal epithelial",
        ["KRT5", "KRT14", "KRT17", "TP63", "DST"],
        ["EPCAM"],
        metadata=_meta("epithelial", "pan-solid-tissue", "solid_tissue_core", role="optional", lineage_module="parenchymal"),
    )
    luminal_ep = _mp(
        "Luminal epithelial",
        ["EPCAM", "KRT8", "KRT18", "KRT19", "MSLN"],
        ["KRT5"],
        metadata=_meta("epithelial", "pan-solid-tissue", "solid_tissue_core", role="optional", lineage_module="parenchymal"),
    )
    epithelial = _mp(
        "Epithelial",
        ["EPCAM", "KRT8", "KRT18", "KRT19", "MSLN"],
        ["COL1A1", "PTPRC", "PECAM1", "VWF"],
        children=[luminal_ep, basal_ep],
        metadata=_meta("solid_tissue", "pan-solid-tissue", "solid_tissue_core", role="major", lineage_module="parenchymal"),
    )
    return [epithelial]


def _stromal_core() -> List[MarkerProgram]:
    fibro = _mp(
        "Fibroblast",
        ["COL1A1", "COL1A2", "DCN", "LUM", "COL3A1"],
        ["EPCAM", "PTPRC", "PECAM1", "KDR"],
        children=[],
        metadata=_meta("solid_tissue", "pan-solid-tissue", "solid_tissue_core", role="major", lineage_module="stromal"),
    )
    return [fibro]


def _vascular_core() -> List[MarkerProgram]:
    cap_endo = _mp(
        "Capillary endothelial",
        ["PECAM1", "EMCN", "KDR", "RGCC", "CA4"],
        ["ACKR1", "GJA5"],
        metadata=_meta("endothelial", "pan-solid-tissue", "solid_tissue_core", role="optional", lineage_module="vascular"),
    )
    endothelial = _mp(
        "Endothelial",
        ["PECAM1", "VWF", "EMCN", "KDR", "CLDN5"],
        ["COL1A1", "EPCAM", "PTPRC"],
        children=[cap_endo],
        metadata=_meta("solid_tissue", "pan-solid-tissue", "solid_tissue_core", role="major", lineage_module="vascular"),
    )
    return [endothelial]


def _mural_core() -> List[MarkerProgram]:
    pericyte = _mp(
        "Pericyte",
        ["RGS5", "MCAM", "CSPG4", "PDGFRB", "DES"],
        ["MYH11", "CNN1", "EPCAM", "KRT8", "KRT18", "KRT19"],
        metadata=_meta("mural", "pan-solid-tissue", "solid_tissue_core", role="major", lineage_module="mural"),
    )
    mural = _mp(
        "Mural",
        ["RGS5", "MCAM", "CSPG4", "ACTA2", "MYH11"],
        ["EPCAM", "PTPRC"],
        children=[pericyte],
        metadata=_meta("solid_tissue", "pan-solid-tissue", "solid_tissue_core", role="major", lineage_module="mural"),
    )
    return [mural]


def _solid_tissue_core() -> List[MarkerProgram]:
    return _parenchymal_fallback_core() + _stromal_core() + _vascular_core() + _mural_core()


def _tissue_origin_screen() -> List[MarkerProgram]:
    """Balanced tissue-origin screening hierarchy.

    This hierarchy is intended for :func:`hierannot.detect_tissue_type`, not for
    final cell-type annotation.  It is deliberately shallow and two-layered:
    shared TME controls absorb immune/stromal/vascular/mural clusters, while
    tissue-informative branches compare broad lineage anchors in a common
    competition space.  Tissue anchors avoid tumor/stress-state markers where
    possible so the screen reflects tissue origin rather than tumor state.
    """

    def anchor(name, pos, neg, tissue_candidate, recommended_hierarchy, description):
        meta = _meta(
            "tissue_origin_anchor",
            tissue_candidate,
            "tissue_origin_screen",
            role="major",
            lineage_module=f"{tissue_candidate}_anchor",
        )
        meta.update({
            "builtin_purpose": "tissue_origin_screen",
            "tissue_detection_role": "anchor",
            "tissue_candidate": tissue_candidate,
            "recommended_hierarchy": recommended_hierarchy,
            "contributes_to_tissue_detection": True,
        })
        return _mp(name, pos, neg, description=description, metadata=meta)

    def shared(name, pos, neg, description):
        meta = _meta(
            "tissue_origin_shared_control",
            "pan-tissue",
            "tissue_origin_screen",
            role="major",
            lineage_module="shared_tme_control",
        )
        meta.update({
            "builtin_purpose": "tissue_origin_screen",
            "tissue_detection_role": "shared_control",
            "tissue_candidate": "generic_tme",
            "recommended_hierarchy": "tme_core",
            "contributes_to_tissue_detection": False,
        })
        return _mp(name, pos, neg, description=description, metadata=meta)

    shared_controls = _mp(
        "Shared TME controls",
        ["PTPRC", "COL1A1", "PECAM1", "VWF", "RGS5"],
        ["EPCAM", "KRT8", "KRT18", "KRT19"],
        children=[
            shared(
                "Shared immune control",
                ["PTPRC", "CD53", "LST1", "TYROBP", "HLA-DRA", "CD3D", "MS4A1", "LYZ"],
                ["EPCAM", "COL1A1", "PECAM1"],
                "Shared immune/TME control branch; contributes to generic TME support but not to a specific tissue call.",
            ),
            shared(
                "Shared fibroblast/stromal control",
                ["COL1A1", "COL1A2", "COL3A1", "DCN", "LUM", "SPARC"],
                ["EPCAM", "PTPRC", "PECAM1"],
                "Shared stromal control branch; contributes to generic TME support but not to a specific tissue call.",
            ),
            shared(
                "Shared endothelial control",
                ["PECAM1", "VWF", "KDR", "EMCN", "CLDN5"],
                ["EPCAM", "PTPRC", "COL1A1"],
                "Shared endothelial control branch; contributes to generic TME support but not to a specific tissue call.",
            ),
            shared(
                "Shared mural control",
                ["RGS5", "MCAM", "CSPG4", "PDGFRB", "ACTA2", "MYH11"],
                ["EPCAM", "PTPRC", "PECAM1"],
                "Shared mural/pericyte control branch; contributes to generic TME support but not to a specific tissue call.",
            ),
        ],
        description="Shared immune, stromal, endothelial, and mural controls for tissue-origin screening.",
        metadata=_meta("tissue_origin_shared_control", "pan-tissue", "tissue_origin_screen", role="major", lineage_module="shared_tme_control"),
    )

    epithelial_anchors = _mp(
        "Epithelial/parenchymal tissue anchors",
        ["EPCAM", "KRT8", "KRT18", "KRT19", "KRT5", "KRT14"],
        ["PTPRC", "COL1A1", "PECAM1", "VWF"],
        children=[
            anchor(
                "Mammary epithelial anchor",
                ["EPCAM", "KRT8", "KRT18", "KRT19", "MUC1", "GATA3", "FOXA1", "ESR1", "PGR"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF"],
                "breast",
                "breast_tme",
                "Broad mammary epithelial anchor for breast tissue-origin screening.",
            ),
            anchor(
                "Intestinal epithelial anchor",
                ["EPCAM", "KRT20", "CDX2", "VIL1", "FABP1", "MUC2", "TFF3", "SLC26A3"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF"],
                "colon",
                "colon_tme",
                "Broad intestinal epithelial anchor for colon/intestinal tissue-origin screening.",
            ),
            anchor(
                "Renal parenchymal anchor",
                ["LRP2", "CUBN", "SLC34A1", "UMOD", "AQP2", "NPHS1", "PODXL"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF"],
                "kidney",
                "kidney_tme",
                "Broad renal parenchymal anchor for kidney tissue-origin screening.",
            ),
            anchor(
                "Pancreatic parenchymal anchor",
                ["PRSS1", "CPA1", "CPB1", "REG1A", "KRT19", "SOX9", "INS", "GCG"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF"],
                "pancreas",
                "pancreas_tme",
                "Broad pancreatic acinar/ductal/endocrine anchor for pancreas tissue-origin screening.",
            ),
            anchor(
                "Hepatic parenchymal anchor",
                ["ALB", "APOA1", "APOH", "TTR", "HP", "CPS1", "KRT19", "KRT7"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF"],
                "liver",
                "liver_tme",
                "Broad hepatocyte/cholangiocyte anchor for liver tissue-origin screening.",
            ),
            anchor(
                "Pulmonary epithelial anchor",
                ["EPCAM", "SFTPA1", "SFTPB", "SFTPC", "AGER", "SCGB1A1", "FOXJ1", "NAPSA"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF"],
                "lung",
                "lung_tme",
                "Broad lung epithelial anchor for pulmonary tissue-origin screening.",
            ),
            anchor(
                "Squamous/keratinocyte epithelial anchor",
                ["KRT5", "KRT14", "TP63", "KRT1", "KRT10", "IVL", "DSG1", "FLG", "LOR"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF", "MLANA"],
                "squamous_epithelial",
                "skin_tme", # prefer skin over tonsil, even though it supports both without distinction.
                "Keratinocyte/squamous epithelial anchor. This supports a squamous epithelial context. Recommend `skin_tme` over `tonsil_tme` due to higher coverage although it cannot distinguish skin from tonsil/oropharynx without sample metadata.",
            ),
        ],
        description="Broad epithelial/parenchymal anchors for tissue-origin screening.",
        metadata=_meta("tissue_origin_branch", "pan-solid-tissue", "tissue_origin_screen", role="major", lineage_module="epithelial_parenchymal_anchors"),
    )

    melanocytic_anchors = _mp(
        "Melanocytic tissue anchors",
        ["MITF", "PMEL", "MLANA", "TYR", "TYRP1", "DCT", "SOX10"],
        ["PTPRC", "COL1A1", "PECAM1", "VWF", "KRT14"],
        children=[
            anchor(
                "Melanocyte anchor",
                ["MITF", "PMEL", "MLANA", "TYR", "TYRP1", "DCT", "SOX10"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF", "KRT14"],
                "skin",
                "skin_tme",
                "Melanocyte anchor for skin/melanocytic tissue-origin screening.",
            ),
        ],
        description="Melanocytic lineage anchor branch for tissue-origin screening.",
        metadata=_meta("tissue_origin_branch", "skin", "tissue_origin_screen", role="major", lineage_module="melanocytic_anchor"),
    )

    neural_anchors = _mp(
        "Neural/glial tissue anchors",
        ["SNAP25", "SYT1", "RBFOX3", "TUBB3", "AQP4", "GFAP", "MOG", "MBP", "OLIG1"],
        ["PTPRC", "COL1A1", "PECAM1", "EPCAM"],
        children=[
            anchor(
                "Neural/glial anchor",
                ["SNAP25", "SYT1", "RBFOX3", "TUBB3", "AQP4", "GFAP", "MOG", "MBP", "OLIG1"],
                ["PTPRC", "COL1A1", "PECAM1", "EPCAM"],
                "brain",
                "brain_core",
                "Broad neural/glial anchor for brain-like tissue-origin screening.",
            ),
        ],
        description="Neural and glial lineage anchor branch for tissue-origin screening.",
        metadata=_meta("tissue_origin_branch", "brain", "tissue_origin_screen", role="major", lineage_module="neural_glial_anchor"),
    )

    return [shared_controls, epithelial_anchors, melanocytic_anchors, neural_anchors]

def _brain_core() -> List[MarkerProgram]:
    excit = _mp(
        "Excitatory neuron",
        ["SLC17A7", "CAMK2A", "SATB2", "NRGN", "SYT1"],
        ["GAD1", "AIF1"],
        metadata=_meta("brain", "brain", "brain_core", role="optional", lineage_module="brain_parenchymal"),
    )
    inhib = _mp(
        "Inhibitory neuron",
        ["GAD1", "GAD2", "SLC6A1", "DLX1", "DLX2"],
        ["SLC17A7", "AIF1"],
        metadata=_meta("brain", "brain", "brain_core", role="optional", lineage_module="brain_parenchymal"),
    )
    neuron = _mp(
        "Neuron",
        ["RBFOX3", "SNAP25", "SYT1", "TUBB3", "STMN2"],
        ["AQP4", "AIF1"],
        [excit, inhib],
        metadata=_meta("brain", "brain", "brain_core", role="major", lineage_module="brain_parenchymal"),
    )
    astro = _mp(
        "Astrocyte",
        ["AQP4", "GFAP", "SLC1A3", "ALDH1L1", "GJA1"],
        ["RBFOX3", "MOG"],
        metadata=_meta("brain", "brain", "brain_core", role="major", lineage_module="brain_parenchymal"),
    )
    olig = _mp(
        "Oligodendrocyte",
        ["MOG", "MBP", "PLP1", "MOBP", "MAG"],
        ["AIF1", "AQP4"],
        metadata=_meta("brain", "brain", "brain_core", role="major", lineage_module="brain_parenchymal"),
    )
    opc = _mp(
        "OPC",
        ["PDGFRA", "CSPG4", "OLIG1", "OLIG2", "SOX10"],
        ["MOG", "AIF1"],
        metadata=_meta("brain", "brain", "brain_core", role="major", lineage_module="brain_parenchymal"),
    )
    micro = _mp(
        "Microglia",
        ["AIF1", "P2RY12", "TMEM119", "CX3CR1", "TYROBP"],
        ["RBFOX3", "MOG"],
        metadata=_meta("brain", "brain", "brain_core", role="major", lineage_module="brain_immune"),
    )
    endot = _mp(
        "Endothelial",
        ["PECAM1", "CLDN5", "KDR", "EMCN", "VWF"],
        ["AQP4", "RBFOX3"],
        metadata=_meta("brain", "brain", "brain_core", role="major", lineage_module="vascular"),
    )
    return [neuron, astro, olig, opc, micro, endot]


def _tme_core() -> List[MarkerProgram]:
    roots = _solid_tissue_core()
    roots.append(_mp("Immune", ["PTPRC", "TYROBP", "LST1", "HLA-DRA", "CD53"], ["EPCAM", "COL1A1"], _immune_core(), "Top-level immune branch for mixed tissue microenvironments.", metadata=_meta("tme", "pan-solid-tissue", "tme_core")))
    return roots


def _colon_tme() -> List[MarkerProgram]:
    roots = _tme_core()
    for i, node in enumerate(roots):
        if node.name == "Epithelial":
            roots[i] = _mp(
                "Intestinal epithelial",
                ["KRT20", "CEACAM1", "SLC26A3", "MUC2", "TFF3", "SOX9"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF"],
                children=[
                    _mp("Absorptive-like", ["KRT20", "CA1", "CEACAM1", "SLC26A3", "FABP1"], ["MUC2"], metadata=_meta("epithelial", "colon", "colon_tme", role="major", lineage_module="colon_parenchymal")),
                    _mp("Goblet-like", ["MUC2", "TFF3", "SPINK4", "CLCA1", "AGR2"], ["CA1"], metadata=_meta("epithelial", "colon", "colon_tme", role="major", lineage_module="colon_parenchymal")),
                    _mp("Stem/TA-like", ["LGR5", "OLFM4", "MKI67", "SOX9", "ASCL2"], ["KRT20"], metadata=_meta("epithelial", "colon", "colon_tme", role="optional", lineage_module="colon_parenchymal")),
                ],
                metadata=_meta("solid_tissue", "colon", "colon_tme", role="major", lineage_module="colon_parenchymal"),
            )
    return roots

def _kidney_tme() -> List[MarkerProgram]:
    roots = _tme_core()
    for i, node in enumerate(roots):
        if node.name == "Epithelial":
            roots[i] = _mp(
                "Renal parenchymal",
                ["LRP2", "CUBN", "SLC34A1", "UMOD", "KRT19", "AQP2", "NPHS1"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF"],
                children=[
                    _mp("Proximal tubule", ["LRP2", "CUBN", "SLC34A1", "ALDOB", "AQP1"], ["KRT19"], metadata=_meta("epithelial", "kidney", "kidney_tme", role="major", lineage_module="kidney_parenchymal")),
                    _mp("Distal/TAL-like", ["SLC12A1", "UMOD", "KCNJ1", "FXYD2", "CLDN16"], ["LRP2"], metadata=_meta("epithelial", "kidney", "kidney_tme", role="major", lineage_module="kidney_parenchymal")),
                    _mp("Collecting duct", ["KRT19", "EPCAM", "AQP2", "FXYD4", "SCNN1G"], ["LRP2"], metadata=_meta("epithelial", "kidney", "kidney_tme", role="major", lineage_module="kidney_parenchymal")),
                    _mp("Podocyte", ["NPHS1", "NPHS2", "PODXL", "WT1", "SYNPO"], ["KRT19"], metadata=_meta("epithelial", "kidney", "kidney_tme", role="major", lineage_module="kidney_parenchymal")),
                ],
                metadata=_meta("solid_tissue", "kidney", "kidney_tme", role="major", lineage_module="kidney_parenchymal"),
            )
        elif node.name == "Mural":
            node.children = list(node.children) + [
                _mp("Mesangial/pericyte", ["RGS5", "MCAM", "CSPG4", "PDGFRB", "DES"], ["EPCAM", "PTPRC"], metadata=_meta("mural", "kidney", "kidney_tme", role="optional", lineage_module="kidney_stromal")),
            ]
    return roots

def _tonsil_tme() -> List[MarkerProgram]:
    roots = _tme_core()
    for node in roots:
        if node.name == "Epithelial":
            # Keep the generic epithelial parent and basic epithelial fallback subtypes
            # from tme_core, then add a shallow tonsil/oropharyngeal squamous
            # refinement.  This avoids forcing every epithelial cluster into a
            # squamous label while still supporting HNSCC/tonsil contexts.
            node.children = list(node.children) + [
                _mp(
                    "Squamous epithelial",
                    ["KRT5", "KRT14", "TP63", "KRT1", "KRT10", "IVL", "DSG1", "DSG3"],
                    ["PTPRC", "COL1A1", "PECAM1", "VWF", "MLANA", "PMEL"],
                    description="Mucosal squamous epithelial refinement for tonsil/oropharyngeal TME annotation. ",
                    metadata=_meta("epithelial", "tonsil", "tonsil_tme", role="major", lineage_module="tonsil_squamous"),
                )
            ]
            node.description = "Generic epithelial fallback with tonsil/oropharyngeal squamous refinement."
            node.metadata.update(_meta("solid_tissue", "tonsil", "tonsil_tme", role="major", lineage_module="parenchymal"))
    return roots

def _breast_tme() -> List[MarkerProgram]:
    roots = _tme_core()
    for i, node in enumerate(roots):
        if node.name == "Epithelial":
            roots[i] = _mp(
                "Mammary epithelial",
                ["EPCAM", "KRT8", "KRT18", "KRT19", "KRT5", "KRT14"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF"],
                children=[
                    _mp("Luminal epithelial", ["EPCAM", "KRT8", "KRT18", "ESR1", "PGR"], ["KRT5", "KRT14"], metadata=_meta("epithelial", "breast", "breast_tme", role="major", lineage_module="breast_parenchymal")),
                    _mp("Basal epithelial", ["KRT5", "KRT14", "KRT17", "TP63", "KRT15"], ["ESR1", "PGR"], metadata=_meta("epithelial", "breast", "breast_tme", role="major", lineage_module="breast_parenchymal")),
                    _mp("Secretory/alveolar epithelial", ["EPCAM", "KRT8", "KRT18", "ELF5", "CSN2"], ["KRT5"], metadata=_meta("epithelial", "breast", "breast_tme", role="optional", lineage_module="breast_parenchymal")),
                ],
                metadata=_meta("solid_tissue", "breast", "breast_tme", role="major", lineage_module="breast_parenchymal"),
            )
    return roots

def _pancreas_tme() -> List[MarkerProgram]:
    roots = _tme_core()
    for i, node in enumerate(roots):
        if node.name == "Epithelial":
            roots[i] = _mp(
                "Pancreatic parenchymal",
                ["PRSS1", "CPA1", "CPB1", "REG1A", "KRT19", "EPCAM", "CHGA", "CHGB"],
                ["PTPRC", "TYROBP", "PECAM1", "VWF", "COL1A1", "COL1A2"],
                children=[
                    _mp(
                        "Ductal",
                        ["KRT19", "EPCAM", "MSLN", "KRT8", "KRT18"],
                        ["CPA1", "CPB1", "PRSS1"],
                        metadata=_meta("epithelial", "pancreas", "pancreas_tme", role="major", lineage_module="pancreas_parenchymal"),
                    ),
                    _mp(
                        "Acinar",
                        ["PRSS1", "PRSS3", "CPA1", "CPB1", "REG1A"],
                        ["KRT19", "EPCAM", "PECAM1", "VWF", "PTPRC"],
                        metadata=_meta("epithelial", "pancreas", "pancreas_tme", role="major", lineage_module="pancreas_parenchymal"),
                    ),
                    _mp(
                        "Endocrine",
                        ["CHGA", "CHGB", "ISL1", "PAX6", "PCSK1"],
                        ["KRT19", "PRSS1", "CPA1"],
                        metadata=_meta("epithelial", "pancreas", "pancreas_tme", role="major", lineage_module="pancreas_parenchymal"),
                    ),
                ],
                metadata=_meta("solid_tissue", "pancreas", "pancreas_tme", role="major", lineage_module="pancreas_parenchymal"),
            )
        elif node.name == "Fibroblast":
            roots[i] = _mp(
                "Fibroblast",
                ["COL1A1", "COL1A2", "DCN", "LUM", "COL3A1"],
                ["EPCAM", "PTPRC", "PECAM1", "KDR"],
                children=[
                    _mp(
                        "Pancreatic stellate cell",
                        ["COL1A1", "COL1A2", "COL3A1", "DCN", "LUM", "SPARC"],
                        ["PTPRC", "PECAM1", "KDR", "EPCAM"],
                        metadata=_meta("stromal", "pancreas", "pancreas_tme", role="optional", lineage_module="stromal"),
                    ),
                ],
                metadata=_meta("solid_tissue", "pancreas", "pancreas_tme", role="major", lineage_module="stromal"),
            )
        elif node.name == "Endothelial":
            node.negative_markers = ["COL1A1", "EPCAM", "PTPRC"]
        elif node.name == "Immune":
            node.negative_markers = ["EPCAM", "COL1A1", "PECAM1", "VWF"]
            for child in node.children:
                if child.name == "NK cell":
                    child.negative_markers = list(dict.fromkeys(child.negative_markers + ["PRSS1", "CPA1", "CPB1", "PECAM1", "VWF"]))
                elif child.name in {"Myeloid", "T cell", "B cell"}:
                    child.negative_markers = list(dict.fromkeys(child.negative_markers + ["PECAM1", "VWF"]))
    return roots

def _liver_tme() -> List[MarkerProgram]:
    roots = _tme_core()
    for i, node in enumerate(roots):
        if node.name == "Epithelial":
            roots[i] = _mp(
                "Hepatic parenchymal",
                ["ALB", "APOA1", "TTR", "KRT19", "SOX9"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF"],
                children=[
                    _mp("Hepatocyte-like", ["ALB", "APOA1", "TTR", "HP", "CPS1"], ["KRT19"], metadata=_meta("epithelial", "liver", "liver_tme", role="major", lineage_module="liver_parenchymal")),
                    _mp("Cholangiocyte-like", ["KRT19", "EPCAM", "KRT8", "KRT18", "SOX9"], ["ALB"], metadata=_meta("epithelial", "liver", "liver_tme", role="major", lineage_module="liver_parenchymal")),
                ],
                metadata=_meta("solid_tissue", "liver", "liver_tme", role="major", lineage_module="liver_parenchymal"),
            )
        elif node.name == "Fibroblast":
            roots[i] = _mp(
                "Fibroblast",
                ["COL1A1", "COL1A2", "DCN", "LUM", "COL3A1"],
                ["EPCAM", "PTPRC", "PECAM1", "KDR"],
                children=[
                    _mp(
                        "Hepatic stellate cell",
                        ["RBP1", "LRAT", "RELN", "DES", "GFAP", "CYGB"],
                        ["PTPRC", "PECAM1", "KDR", "EPCAM"],
                        metadata=_meta("stromal", "liver", "liver_tme", role="optional", lineage_module="stromal"),
                    ),
                ],
                metadata=_meta("solid_tissue", "liver", "liver_tme", role="major", lineage_module="stromal"),
            )
    return roots

def _lung_tme() -> List[MarkerProgram]:
    roots = _tme_core()
    for i, node in enumerate(roots):
        if node.name == "Epithelial":
            roots[i] = _mp(
                "Pulmonary parenchymal",
                ["SFTPA1", "SFTPB", "SFTPC", "SCGB1A1", "KRT19", "KRT5"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF"],
                children=[
                    _mp("Alveolar epithelial", ["SFTPA1", "SFTPA2", "SFTPB", "SFTPC", "NAPSA"], ["KRT5"], metadata=_meta("epithelial", "lung", "lung_tme", role="major", lineage_module="lung_parenchymal")),
                    _mp("Airway epithelial", ["SCGB1A1", "KRT19", "KRT8", "FOXJ1", "PIFO"], ["SFTPC"], metadata=_meta("epithelial", "lung", "lung_tme", role="major", lineage_module="lung_parenchymal")),
                    _mp("Basal epithelial", ["KRT5", "KRT14", "KRT17", "TP63", "KRT15"], ["SFTPC"], metadata=_meta("epithelial", "lung", "lung_tme", role="major", lineage_module="lung_parenchymal")),
                ],
                metadata=_meta("solid_tissue", "lung", "lung_tme", role="major", lineage_module="lung_parenchymal"),
            )
    return roots

def _skin_tme() -> List[MarkerProgram]:
    roots = _tme_core()
    for i, node in enumerate(roots):
        if node.name == "Epithelial":
            roots[i] = _mp(
                "Cutaneous epithelial",
                ["KRT5", "KRT14", "TP63", "KRT1", "KRT10", "IVL", "DSG1", "FLG", "LOR"],
                ["PTPRC", "COL1A1", "PECAM1", "VWF", "MLANA", "PMEL"],
                children=[
                    _mp(
                        "Basal keratinocyte",
                        ["KRT5", "KRT14", "TP63", "KRT15", "COL17A1", "ITGA6"],
                        ["KRT1", "KRT10", "MLANA"],
                        metadata=_meta("epithelial", "skin", "skin_tme", role="major", lineage_module="skin_parenchymal"),
                    ),
                    _mp(
                        "Differentiated keratinocyte/squamous epithelial",
                        ["KRT1", "KRT10", "IVL", "DSG1", "FLG", "LOR"],
                        ["KRT14", "MLANA", "PTPRC"],
                        metadata=_meta("epithelial", "skin", "skin_tme", role="major", lineage_module="skin_parenchymal"),
                    ),
                    _mp(
                        "Adnexal epithelial",
                        ["KRT15", "SOX9", "KRT19", "EPCAM", "KRT7"],
                        ["MLANA", "PTPRC"],
                        metadata=_meta("epithelial", "skin", "skin_tme", role="optional", lineage_module="skin_parenchymal"),
                    ),
                ],
                description="Cutaneous epithelial branch. ",
                metadata=_meta("solid_tissue", "skin", "skin_tme", role="major", lineage_module="skin_parenchymal"),
            )
    # Reuse the shared fibroblast/stromal, endothelial, mural, and immune branches
    # from tme_core to avoid marker drift across tissue-specific built-ins.  Add
    # only the skin-specific melanocytic branch as an additional top-level root.
    roots.insert(1, _mp(
        "Melanocyte",
        ["MITF", "PMEL", "MLANA", "TYR", "TYRP1", "DCT", "SOX10"],
        ["KRT14", "PTPRC", "COL1A1", "PECAM1"],
        metadata=_meta("melanocytic", "skin", "skin_tme", role="major", lineage_module="melanocytic"),
    ))
    return roots
